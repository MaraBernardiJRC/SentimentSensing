clear all
close all
%% parameters to modify
save_res = 1;
%to generate plots on the left panels of figure 21
rob_0_1 = 0;

%to generate plots on the right panels of figure 21
rob_0_1 = 1;

%%  parameters fixed for the purposes of reproduce the plots in Figure 21
years = [2020 2021 2022];
current_ds_type='baseline';
nMS= 27;
inters = 1:nMS;

%% loop to generate plots in first, second and third line of Figure 21
for j=1:length(years)

    current_year = years(j);
    current_input_ds_name = [current_ds_type '_counts_' num2str(current_year)];
    load(current_input_ds_name);
    eval(['Ntab =' current_input_ds_name ';']);

    %% CA
    if rob_0_1 == 1
        %robust CA
        %control direction of dimension on x and y axes
        changedim = [true,true];
        %detect outliers for robust CA
        if current_year == 2020
            RAW   = FSCorAna(Ntab,'conflev',0.99999,'plots',0,'init',75000);
        elseif  current_year == 2021
            RAW   = FSCorAna(Ntab,'conflev',0.99999,'plots',0,'init',80000);
        elseif  current_year == 2022
            RAW   = FSCorAna(Ntab,'conflev',0.99999,'plots',0,'init',85000);
        end

        current_output_ds_name = [current_input_ds_name '_outliers_rob',num2str(rob_0_1)];
        eval([current_output_ds_name '= RAW.outliers ;']);
        inters = intersect(inters,eval(current_output_ds_name));
        Sup = struct;
        Sup.r = inters;
        %robust CA
        out=CorAna(eval(current_input_ds_name),'Sup',Sup,'plots',0);
    else
        %non robust CA
        %control direction of dimension on x and y axes
        changedim = [false,false];
        out=CorAna(eval(current_input_ds_name),'plots',0);
    end


    % Calculate p-value of chi2 statistics
    df = (out.I - 1) * (out.J - 1);  % degrees of freedom
    pvalue = 1 - chi2cdf(out.Chi2stat, df);
    disp(['chi2 = ' num2str(out.Chi2stat)]);
    disp(['pvalue = ' num2str(pvalue)]);

    %% CA plots
    confellipse=struct;
    confellipse.conflev=0.9999999999999;
    confellipse.selCols=[1,3];
    confellipse.selRows='';
    confellipse.method={'multinomial'}; 

    plots=struct;
    plots.FontSize=14;
    plots.FontSizeSup=14;
    CorAnaplot(out,'confellipse',confellipse,'plots',plots,'changedimsign', changedim)
    legend('off')
    box('on')
    title('')

    yticklabels('')
    xticklabels('')
    handle_lab = findall(gcf,'type','text');
    set(handle_lab,'FontSize',22)
    set(gca,'fontsize',22)

    if save_res
        saveas(gcf, [pwd filesep 'output_rob', rob_0_1,current_input_ds_name]);
        saveas(gcf, [pwd filesep 'output_rob',rob_0_1, current_input_ds_name '.eps'],'epsc');
    end

end